#!/bin/bash
SOURCE=${1:-.}
DES=${2:-.}
TIME_STAMP=$(date +%Y%m%d%H%M%S)
BACKUP="$DES/$TIME_STAMP"
mkdir -p $BACKUP
for FILE in $SOURCE/*; do
    if [ -f "$FILE" ]; then
        echo "Back up: $FILE"

    fi
done

