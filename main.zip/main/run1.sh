#!/bin/bash

cp advantech-logo-1200.png backup1/
cp advantech-logo-150.png backup1/
cp advantech-logo-600.png backup1/
cp advantech-logo-SQR.jpg backup1/
cp readme.txt backup1/
