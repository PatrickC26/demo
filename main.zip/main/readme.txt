Line 1 this is a readme file
Line 2 
Line 3 for Advantech EIoT lesson
Line 4 
Line 5 there are 4 images in this folder
Line 6 
Line 7 these 4 images are Advantech logo
Line 8 
Line 9 all students and users should follow the T&Cs from Advantech
Line 10 
Line 11 you can add other readme info after this Line
Line 12 
Line 13 
Line 14 
Line 15 
Line 16 
Line 17 
Line 18 
Line 19 
Line 20 
