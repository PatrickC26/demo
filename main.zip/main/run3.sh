#!/bin/bash
SOURCE=${1:-.}

TIME_STAMP=$(date +%Y%m%d%H%M%S)

mkdir -p $BACKUP
cp advantech-logo-1200.png $BACKUP
cp advantech-logo-150.png $BACKUP
cp advantech-logo-600.png $BACKUP
cp advantech-logo-SQR.jpg $BACKUP
cp readme.txt $BACKUP
