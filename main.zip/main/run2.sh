#!/bin/bash
TIME_STAMP=$(date +%Y%m%d%H%M%S)

mkdir $BACKUP
cp advantech-logo-1200.png $BACKUP
cp advantech-logo-150.png $BACKUP
cp advantech-logo-600.png $BACKUP
cp advantech-logo-SQR.jpg $BACKUP
cp readme.txt backup1/
